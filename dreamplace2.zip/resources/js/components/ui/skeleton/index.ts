export { default as Skeleton } from './Skeleton.vue'
