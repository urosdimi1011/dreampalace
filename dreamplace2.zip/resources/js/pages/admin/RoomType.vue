<template>
    <admin-layout>
        <p>Room type</p>
    </admin-layout>
</template>
<script setup>
import AdminLayout from "@/layouts/admin/adminLayout.vue";
</script>
